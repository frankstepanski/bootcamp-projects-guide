import { useState } from "react";

function Todo({ todo, completeTodo, deleteTodo, editTodo }) {
  /*
      - Todo contains local state:
           - edit (true or false): trigger rendering other elements
           - text (string): todo text that will change if user decides to update todo text
      - We need o conditionally render different elements:
           - <span>todo text</span> with two buttons (delete and edit) 
           OR
           - <input value = text (from state)> and two buttons (update and cancel)
  */

  const [edit, setEdit] = useState(false);
  const [text, setText] = useState(todo.text);

  const toggleEdit = () => {
    setEdit(!edit);
  };

  const handleEdit = (evt) => {
    setText(evt.target.value);
  };

  const handleUpdate = (id, text) => {
    editTodo(id, text);
    toggleEdit();
  };

  /*
      We need to conditionally render elements depending on user clicking the "edit" button or not
      When user clicks "edit":
          - triggers a change in state (edit) and will re-render the <Todo>
          - edit (state) will be true and will render the elements defined in the falsy (:) expression
      When component first renders:
          - edit (state) is false by default and renders the todo text in a <span>

      Note: Conditionally rendering elements in a component can be done by if, ternary, short-circuit operator
            
      https://www.robinwieruch.de/conditional-rendering-react
      https://www.digitalocean.com/community/tutorials/7-ways-to-implement-conditional-rendering-in-react-applications
  
  */
  return (
    <li>
      <input
        type="checkbox"
        checked={todo.isCompleted}
        onChange={() => completeTodo(todo.id)}
      />
      {/* ternary ? if truthy, renders text wrapped in <span> : if falsy, renders input field to edit */}
      {!edit ? (
        <>
          <span
            style={{ textDecoration: todo.isCompleted ? "line-through" : "" }}
          >
            {" "}
            {todo.text}{" "}
          </span>
          <button onClick={() => deleteTodo(todo.id)}>X</button>
          <button onClick={() => toggleEdit()} disabled={todo.isCompleted}>
            Edit
          </button>
        </>
      ) : (
        <>
          <input
            type="text"
            className="input"
            value={text}
            onChange={(evt) => handleEdit(evt)}
          />
          <button onClick={() => handleUpdate(todo.id, text)}>Update</button>
          <button onClick={() => toggleEdit()}> Cancel </button>
        </>
      )}
    </li>
  );
}

export default Todo;
