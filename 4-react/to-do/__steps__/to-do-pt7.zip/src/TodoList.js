import Todo from "./Todo";

function TodoList({ todos, completeTodo, editTodo, deleteTodo }) {
  // let's see the changes to todos that are made in <todo>
  console.log(todos);

  const listTodos = todos.map((todo) => {
    return (
      <Todo
        key={todo.id}
        todo={todo}
        completeTodo={completeTodo}
        editTodo={editTodo}
        deleteTodo={deleteTodo}
      />
    );
  });

  return (
    <>
      <ul>{listTodos}</ul>
    </>
  );
}

export default TodoList;
