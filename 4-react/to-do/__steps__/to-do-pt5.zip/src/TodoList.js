import Todo from "./Todo";

/*
   TodoList receives props: 
     1) todos array 2) completeTodo function
    Iterates (map) each object (todo) in todos array:
     Passes props to the <Todo> component:
       1) key to identify each element
       2) todo object
       3) completeTodo function
*/
function TodoList({ todos, completeTodo }) {
    // notice when <TodoList> re-renders (change in props)
    console.log("<TodoList> component render");

    return (
        <ul>
            {todos.map((todo) => {
                return (
                    <Todo
                        key={todo.id}
                        todo={todo}
                        completeTodo={completeTodo}
                    />
                );
            })}
        </ul>
    );
}

export default TodoList;
