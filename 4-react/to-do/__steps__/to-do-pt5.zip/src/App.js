import { useState } from "react";
import TodoList from "./TodoList";

import { listoftodos } from "./data";
import "./styles.css";

// Adding State to <App>:
function App() {
    // notice when <App> re-renders (change in state)
    console.log("<App> component render");

    // Storing array of todo objects in state (to keep track of changes)
    const [todos, setTodos] = useState(listoftodos);

    /*  
        Lifting Up State: 
        When a component needs state (data), the objective or recommended pattern in React
        is to keep state and any functions that will update that state at the 'highest'
        component in the hierarchy.

        App =>
             TodoList =>
                      Todo
                      
        The state needed for a todo item will be used in the <Todo> component.
        Since the state will be changed in <Todo> via an event (clicking checkbox),
        it needs a function to update the state. 
        
        So the state and the function can be defined in <App> and passed down via props.
        When state is updated from the function that was passed down from <App> it is
        called "lifting state" because the state needs to be "lifted" back up to the 
        component that it was defined which was <App>.    

        This pattern allows multiple components to "share state" (in the ancestry chain).
        You do not want individual components creating their own local state unless they 
        are not a parent or child component.
        
        https://reactjs.org/docs/lifting-state-up.html
    */

    const completeTodo = (id) => {
        const temporaryTodos = [...todos]; // shallow copy (aka. Object.assign())
        const index = temporaryTodos.findIndex((todo) => todo.id === id);
        temporaryTodos[index].isCompleted = !temporaryTodos[index].isCompleted; // toggle isCompleted
        setTodos(temporaryTodos);
    };

    return (
        // Passing completeTodo function to <TodoList> component
        <>
            <TodoList todos={todos} completeTodo={completeTodo} />
        </>
    );
}

export default App;
