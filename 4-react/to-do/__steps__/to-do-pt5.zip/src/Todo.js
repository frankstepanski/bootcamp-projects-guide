/*
    Each todo is rendered as an <LI>.
      - checked attribute is (true|false) set by the value of todo.isCompleted
      - when the value of the checked is changed by the user, triggers completeTodo()
      - the completeTodo function (passed down from <App />) 
   
    Events in React:
      - React simulates JavaScript/DOM events and since with React you don't have to
        interact with the DOM (unless you really want to), all that addEventListener
        stuff you never have to do. You will just reference the event inline inside
        each form element you want to use in the component.
      - The "synthentic" onChange event is being used to invoke the completetodo function
        that the component received from <App> as a prop.
      - Normally you will use arrow function syntax inside an event handler, as the function
        you are defining (not the execution) will be used in the event. This will prevent 
        the function from executing when the component is being rendered (which you don't want)

    https://reactjs.org/docs/handling-events.html
    https://blog.logrocket.com/a-guide-to-react-onclick-event-handlers-d411943b14dd/

    completeTodo: function will be called and update state property
*/

function Todo({ todo, completeTodo }) {
    // notice when <Todo> re-renders (change in props)
    console.log("<Todo> component render");

    return (
        <li>
            <input
                type="checkbox"
                checked={todo.isCompleted}
                onChange={() => completeTodo(todo.id)}
            />
            <span> {todo.text} </span>
        </li>
    );
}

export default Todo;
