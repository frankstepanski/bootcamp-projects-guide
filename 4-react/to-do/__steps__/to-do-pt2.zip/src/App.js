import TodoList from "./TodoList";
import "./styles.css";

/*
    Note: Now we are populating our values for each todo from an array objects.
    Though we are still "hard-coding" each <LI> in our <TodoList>, it is
    a step in the right direction. 
*/

function App() {
  // array of objects (todo items)
  const todos = [
    { text: "goto gym" },
    { text: "do laundry" },
    { text: "food shopping" },
    { text: "do homework" }
  ];

  return (
    <>
      {/*  passing prop called todos to <TodoList> component  */}
      <TodoList todos={todos} />
    </>
  );
}

export default App;
