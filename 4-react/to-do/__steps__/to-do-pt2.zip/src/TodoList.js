/*
    Note: You can also "destructure" the props object to the specific property(ies) you define:
    
    https://www.freecodecamp.org/news/the-basics-of-destructuring-props-in-react-a196696f5477/
*/

function TodoList(props) {
  console.log("<TodoList> rendered");
  return (
    <ul>
      <li>
        {/*  props.todos[0].text => first element in array, text property */}
        <input type="checkbox" /> <span> {props.todos[0].text} </span>
      </li>
      <li>
        <input type="checkbox" /> <span> {props.todos[1].text} </span>
      </li>
      <li>
        <input type="checkbox" /> <span> {props.todos[2].text} </span>
      </li>
      <li>
        <input type="checkbox" /> <span> {props.todos[3].text} </span>
      </li>
    </ul>
  );
}

export default TodoList;
