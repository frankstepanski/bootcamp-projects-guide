import TodoList from "./TodoList";
import "./styles.css";

/*
    There are class and functional components.

    For a new React project, using only functional components is the recommedation, 
    but for supporting legacy React projects understanding how to create a class
    component would be beneficial.

    Note: Every component will be "exported" because every component will be 
          "invoked" in another component(s).
*/

function App() {
  return (
    <>
      {/* Invoking our <TodoList> component: */}
      <TodoList />
    </>
  );
}

export default App;
