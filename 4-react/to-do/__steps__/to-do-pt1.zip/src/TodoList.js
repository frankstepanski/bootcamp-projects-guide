/*
   The TodoList component is a functional component that
   just renders HTML and nothing else. 

   This type of component can be considered a "dumb" component:
   https://www.digitalocean.com/community/tutorials/react-smart-dumb-components

   It contains no state (local data) and only focuses on the UI.
   Dumb components can accept props (read-only data).

*/

function TodoList() {
  /*

     Difference between a React element and React component:

     element (any complete HTML element rendered inside our JSX):
     <li>
        <input type="checkbox" /> <span> goto gym </span>
      </li>

     component (referenced in another component):
     <TodoList />
     
     Notice how we are repeating the same elements (<li>) in our JSX. It is not recommended
     because we are restricting how the component will render the UI.
    
     Note: We should "iterate" through a data collection and render each element
     via a child component, instead of doing it this way (we will change this later).

  */
  return (
    <ul>
      <li>
        <input type="checkbox" /> <span> goto gym </span>
      </li>
      <li>
        <input type="checkbox" /> <span> do laundry </span>
      </li>
      <li>
        <input type="checkbox" /> <span> food shopping </span>
      </li>
      <li>
        <input type="checkbox" /> <span> do homework </span>
      </li>
    </ul>
  );
}

export default TodoList;
