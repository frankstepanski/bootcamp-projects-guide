/*
    Each todo is rendered as an <LI>.
      - checked attribute is (true|false) set by the value of todo.isCompleted
      - when the value of the checked is changed by the user, triggers completeTodo()
      - when the button is clicked, the onClick event triggers deleteTodo()
      - the completeTodo function (passed down from <App />) 
      - the deleteTodo function (passed down from <App />)
*/

function Todo({ todo, completeTodo, deleteTodo }) {
  // notice when <Todo> re-renders (change in props)
  console.log("<Todo> component render");

  return (
    <li>
      <input
        type="checkbox"
        checked={todo.isCompleted}
        onChange={() => completeTodo(todo.id)}
      />
      <span style={{ textDecoration: todo.isCompleted ? "line-through" : "" }}>
        {" "}
        {todo.text}{" "}
      </span>
      <button onClick={() => deleteTodo(todo.id)}>X</button>
    </li>
  );
}

export default Todo;
