import Todo from "./Todo";

function TodoList({ todos, completeTodo, deleteTodo }) {
  // notice when <TodoList> re-renders (change in props)
  console.log("<TodoList> component render");

  const listTodos = todos.map((todo) => {
    return (
      <Todo
        key={todo.id}
        todo={todo}
        completeTodo={completeTodo}
        deleteTodo={deleteTodo}
      />
    );
  });

  return (
    <>
      <ul>{listTodos}</ul>
    </>
  );
}

export default TodoList;
