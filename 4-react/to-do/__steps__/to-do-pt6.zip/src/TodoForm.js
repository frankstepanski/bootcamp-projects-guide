import { useState } from "react";

/*
   TodoForm:
      - has it's own state properties (not passed anywhere): 
          - errorMessage and text
      - the form is a "controlled" form, as form elements are
        maintained in their own state variables and are based on
        user input (keypress, click, etc.)

        https://reactjs.org/docs/forms.html#controlled-components

        Note: an "uncontrolled" form can be used if needed
              but would require a hook like useRef to get the form
              values from the DOM
*/

function TodoForm({ addTodo }) {
  const [errorMessage, setErrorMessage] = useState("");
  const [text, setText] = useState("");

  const handleSubmit = (evt) => {
    evt.preventDefault();
    // validate: confirm input is not undefined
    if (text === "") {
      setErrorMessage("todo cannot be empty");
      return;
    } else {
      // using function (addTodo) passed as a prop
      addTodo(text);
      // clear input value (causes <TodoForm to re-render)
      setText("");
    }
  };

  // This function is triggered on every keystroke in <input>
  const handleChange = (evt) => {
    if (errorMessage) setErrorMessage("");
    // showing the React synthentic event:
    console.log(evt);
    setText(evt.target.value);
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <label>
          New Todo:
          <input
            type="text"
            className="input"
            value={text}
            onChange={(evt) => handleChange(evt)}
          />
        </label>
        <button>Add</button>
      </form>
      <div className="error">{errorMessage}</div>
    </>
  );
}

export default TodoForm;
