import { useState } from "react";
import TodoList from "./TodoList";
import TodoForm from "./TodoForm";
import { v4 as uuidv4 } from "uuid";

import { listoftodos } from "./data";
import "./styles.css";

function App() {
  // notice when <App> re-renders (change in state)
  console.log("<App> component render");

  const [todos, setTodos] = useState(listoftodos);

  const completeTodo = (id) => {
    const temporaryTodos = [...todos];
    const index = temporaryTodos.findIndex((todo) => todo.id === id);
    temporaryTodos[index].isCompleted = !temporaryTodos[index].isCompleted;
    setTodos(temporaryTodos);
  };

  const addTodo = (msg) => {
    const newTodo = [
      ...todos,
      {
        id: uuidv4(),
        text: msg,
        isCompleted: false
      }
    ];
    setTodos(newTodo);
  };

  const deleteTodo = (id) => {
    const temporaryTodos = [...todos];
    const newTodos = temporaryTodos.filter((todo) => todo.id !== id);
    setTodos(newTodos);
  };

  /*
      Our component hierarchy has changed to:

      App =>
            TodoForm
            TodoList =>
                      Todo

      note: <Todoform> and <TodoList> are "siblings" as opposed to an
            "parent to child" with <TodoList> and <Todo>
  */

  return (
    <>
      <TodoForm addTodo={addTodo} />
      <TodoList
        todos={todos}
        completeTodo={completeTodo}
        deleteTodo={deleteTodo}
      />
    </>
  );
}

export default App;
