// We are de-constructing our props object to its todos property:
function TodoList({ todos }) {
  /*
     Instead of "hard coding" each <LI> for each todo item, 
     we are iterating through the objects in the todos array.

     The key attrbiute is not required but "recommended" for lists
     for optimization by React (tracking what has changed). 
     The map method of an array has an index argument value 
     we can use for the unique key value (better options are available).

    https://reactjs.org/docs/lists-and-keys.html#keys
  */
  return (
    <ul>
      {todos.map((todo, index) => {
        return (
          <li key={index}>
            <input type="checkbox" /> <span> {todo.text} </span>
          </li>
        );
      })}
    </ul>
  );
}

export default TodoList;
