export const todos = [
  { text: "goto gym" },
  { text: "do laundry" },
  { text: "food shopping" },
  { text: "do homework" }
];
