import TodoList from "./TodoList";
import { todos } from "./data";
import "./styles.css";

function App() {
  return (
    <>
      <TodoList todos={todos} />
    </>
  );
}

export default App;
